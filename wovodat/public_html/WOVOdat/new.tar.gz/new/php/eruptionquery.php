<?php
	/**
	*	This class supports query the information from ed and ed_phs table
	* 	
	*/
	class EruptionQuery {

		/**
		*	Given a volcano Id, return all eruption belonged to it
		*	@param: 
		*		vd_id
		*	@return"
		*		eruption list
		*/
		public static function getEruptionList($vd_id) {
			$result = array();
			$ed_idList = EruptionQuery::getEruptionIdList($vd_id);
			foreach ($ed_idList as $ed_idRow) {
				array_push($result, EruptionQuery::getEruption($ed_idRow["ed_id"]));
			}
			return $result;
		}

		/**
		*	Given a volcano Id, return list of Eruption Id belonged to it
		*	@param:
		*		vd_id
		*	@return:
		*		list of eruption id
		*/
		public static function getEruptionIdList($vd_id) {
			global $db;
			$sql = "select ed_id from ed where ed.vd_id = %d";
			$db->query($sql, $vd_id);
			return $db->getList();
		}

		/**
		*	Given an eruption id, return its information
		*	@param:
		*		ed_id
		*	@return
		*		information of this eruption
		*/
		public static function getEruption($ed_id) {
			$result = array();
			global $db;
			$sql = "select ed_id, ed_stime, ed_etime, ed_vei from ed where ed.ed_id = %d";
			$db->query($sql, $ed_id);
			$result = $db->getRow();
			$result['ed_stime'] = TimeFormatter::getJavascriptTimestamp($result['ed_stime']);
			$result['ed_etime'] = TimeFormatter::getJavascriptTimestamp($result['ed_etime']);
			$result["ed_phs"] = array();
			$ed_phs_idList = EruptionQuery::getEruptionPhaseIdList($ed_id);
			foreach($ed_phs_idList as $ed_phs_idRow) {
				array_push($result["ed_phs"], EruptionQuery::getEruptionPhase($ed_phs_idRow["ed_phs_id"]));
			}
			return $result;
		}


		/**
		*	Given an eruption id, return list of eruption phase id belonged to it
		*	@param:
		*		ed_id
		*	@return:
		*		list of eruption phase id
		*/
		public static function getEruptionPhaseIdList($ed_id) {
			global $db;
			$sql = "select ed_phs_id from ed_phs where ed_phs.ed_id = %d";
			$db->query($sql, $ed_id);
			return $db->getList();
		}

		/**
		*	Given eruption phase id, return its information
		*	@param:
		*		ed_phs_id
		*	@return
		*		eruption phase information
		*/
		public static function getEruptionPhase($ed_phs_id) {
			global $db;
			$sql = "select ed_phs_id, ed_phs_type, ed_phs_stime, ed_phs_etime, ed_phs_vei, ed_phs_dre_tot,
					ed_phs_dre_lav, ed_phs_dre_tep, ed_phs_col from ed_phs where ed_phs.ed_phs_id = %d";
			$db->query($sql, $ed_phs_id);
			$result = $db->getRow();
			$result['ed_phs_stime'] = TimeFormatter::getJavascriptTimestamp($result['ed_phs_stime']);
			$result['ed_phs_etime'] = TimeFormatter::getJavascriptTimestamp($result['ed_phs_etime']);
			return $result;
		}
	}
?>