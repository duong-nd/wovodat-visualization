<?php
	/**
	*	This class supports query the information from vd table
	* 	
	*/
	class VolcanoQuery {

		/**
		*
		*
		*/
		public static function getVolcanoList() {
			$result = array();
			global $db;
			$sql = "select vd_id, vd_name from vd";
			$db->query($sql);
			return $db->getList();
		}
	}
?>