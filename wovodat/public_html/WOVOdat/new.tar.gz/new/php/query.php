<?php
	/**
	*	initiate database
	*/

	define("_SECURITY", true);
	require_once 'database.php';
	$localhost = true;
	if ($localhost) {
		$db = new database('localhost', 'root', 'root', 'wovodat');
	} else {
		$db = new database('', '', '', '');
	}



	require_once "volcanoquery.php";
	require_once "eruptionquery.php";
	require_once "timeformatter.php";

	/**
	*	navigating
	*/
	$data = $_POST['data'];
	switch($data) {
		case "volcano_list":
			loadVolcanoList();
			break;
		case "eruption_list":
			loadEruptionList($_POST['vd_id']);
	}
	/**
	*	@return 
	*		volcano list
	*/

	function loadVolcanoList() {
		$result = VolcanoQuery::getVolcanoList();
		echo json_encode($result);
	}

	/**
	*	Return eruption list belonging to a specific volcano
	*	@param: 
	*		volcano_id
	*	@return:
	*		eruption list
	*/
	function loadEruptionList($volcanoId) {

		$result = EruptionQuery::getEruptionList($volcanoId);
		echo json_encode($result);
	}
?>
