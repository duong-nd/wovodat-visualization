<?php
	/**
	*	This class supports query the data series (deformation, gas, seismic..) for a volcano
	* 	
	*/
	class DataSeriesRepository {

		/**
		*	Given a volcano Id, return all eruption belonged to it
		*	@param: 
		*		$vd_id
		*	@return"
		*		eruption list
		*/
		public static function getDataList($vd_id) {
			$result = array();
			return $result;
		}
  }